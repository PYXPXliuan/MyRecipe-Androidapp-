package com.example.myrecipesample;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

public class ViewNoteActivity extends AppCompatActivity {

    private TextView txtName;
    private TextView txtKw1;
    private TextView txtKw2;
    private TextView txtKw3;
    private TextView txtIngredients;
    private TextView txtCookingStep1;
    private TextView txtCookingStep2;
    private TextView txtCookingStep3;
    private TextView txtCookingStep4;

    private Button btnBack;
    private Button btnEdit;
    private Button btnDelete;

    Intent getIDandF;
    String recipeid = null;
    String userid = null;
    String activity = null;

    HashMap<String, String> recipeDetail = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_note);

        getIDandF = getIntent();

        getView();

        getInfo();

        getRecipeDetail();

        setRecipeDetail();


        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(ViewNoteActivity.this, AddNoteActivity.class);

                intent.putExtra("recipeid", (String) recipeid);
                //pass ativity
                intent.putExtra("activity", (String) "view");

                startActivity(intent);
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(ViewNoteActivity.this, MainActivity.class);
                //pass ativity
                intent.putExtra("activity", (String) "view");
                intent.putExtra("userid", userid);
                startActivity(intent);
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(ViewNoteActivity.this);
                builder.setTitle("Delete Dialog")
                        .setMessage("Are you sure you want to delete?")
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                NoteDBHandler notedbHandler = new NoteDBHandler(ViewNoteActivity.this);
                                notedbHandler.DeleteNote(recipeid);
                                boolean exist = notedbHandler.CheckUser(recipeid, recipeDetail.get("recipename"));

                                if(exist == false)
                                {
                                    Toast.makeText(ViewNoteActivity.this, "Delete success!", Toast.LENGTH_LONG).show();
                                    Intent intent = new Intent(ViewNoteActivity.this, MainActivity.class);
                                    //pass ativity
                                    intent.putExtra("activity", (String) "view");
                                    intent.putExtra("userid", userid);
                                    startActivity(intent);
                                }
                                else
                                {
                                    Toast.makeText(ViewNoteActivity.this, "Delete faild!", Toast.LENGTH_LONG).show();
                                }
                            }
                        })
                        .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(ViewNoteActivity.this, "Delete Process Stop!", Toast.LENGTH_LONG).show();
                            }
                        });
                builder.create().show();
            }
        });
    }

    private void getInfo()
    {
        try
        {
            activity = getIDandF.getStringExtra("activity");

            if(activity.equalsIgnoreCase("main")||activity.equalsIgnoreCase("add"))
            {
                recipeid = getIDandF.getStringExtra("recipeid");

                if(recipeid == null)
                {
                    Toast.makeText(ViewNoteActivity.this, "Error happen 1", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(ViewNoteActivity.this, MainActivity.class);
                    //pass ativity
                    intent.putExtra("activity", (String) "view");
                    startActivity(intent);
                }
            }
            else if(activity == null)
            {
                Toast.makeText(ViewNoteActivity.this, "Error happen 2", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(ViewNoteActivity.this, MainActivity.class);
                //pass ativity
                intent.putExtra("activity", (String) "view");
                startActivity(intent);
            }
        }
        catch (Exception e)
        {
            Toast.makeText(ViewNoteActivity.this, "Error happen 3", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(ViewNoteActivity.this, MainActivity.class);
            //pass ativity
            intent.putExtra("activity", (String) "view");
            startActivity(intent);
        }
    }

    private void getView()
    {
        txtName = (TextView)findViewById(R.id.txtTitleRecipeName);
        txtKw1 = (TextView)findViewById(R.id.txtKeyWord1);
        txtKw2 = (TextView)findViewById(R.id.txtKeyWord2);
        txtKw3 = (TextView)findViewById(R.id.txtKeyWord3);
        txtIngredients = (TextView)findViewById(R.id.txtIngredients);
        txtCookingStep1 = (TextView)findViewById(R.id.txtCookingStep1);
        txtCookingStep2 = (TextView)findViewById(R.id.txtCookingStep2);
        txtCookingStep3 = (TextView)findViewById(R.id.txtCookingStep3);
        txtCookingStep4 = (TextView)findViewById(R.id.txtCookingStep4);

        btnEdit = (Button)findViewById(R.id.btnEdit);
        btnBack = (Button)findViewById(R.id.btnBack);
        btnDelete= (Button)findViewById(R.id.btnDelete);
    }

    private  void getRecipeDetail()
    {
        NoteDBHandler noteDBHandler = new NoteDBHandler(ViewNoteActivity.this);
        recipeDetail = noteDBHandler.ricipedetail(recipeid);
    }

    private void setRecipeDetail()
    {
        txtName.setText(recipeDetail.get("recipename"));
        txtKw1.setText(recipeDetail.get("keyword1"));
        txtKw2.setText(recipeDetail.get("keyword2"));
        txtKw3.setText(recipeDetail.get("keyword3"));
        txtIngredients.setText(recipeDetail.get("ingredients"));
        txtCookingStep1.setText(recipeDetail.get("step1"));
        txtCookingStep2.setText(recipeDetail.get("step2"));
        txtCookingStep3.setText(recipeDetail.get("step3"));
        txtCookingStep4.setText(recipeDetail.get("step4"));
        recipeid = recipeDetail.get("recipeid");
        userid = recipeDetail.get("userid");
    }
}

package com.example.myrecipesample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    private EditText edtRegisterEmail;
    private EditText edtRegisterUsername;
    private EditText edtRegisterPassword;
    private EditText edtRegisterComfirmation;
    private Button btnDone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        edtRegisterEmail = (EditText)findViewById(R.id.edtRegisterEmail);
        edtRegisterUsername = (EditText)findViewById(R.id.edtRegisterUsername);
        edtRegisterPassword = (EditText)findViewById(R.id.edtRegisterPassword);
        edtRegisterComfirmation = (EditText)findViewById(R.id.edtRegisterComfirmation);
        btnDone = (Button)findViewById(R.id.btnDone);

        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email = edtRegisterEmail.getText().toString().trim();
                String username = edtRegisterUsername.getText().toString().trim();
                String password = edtRegisterPassword.getText().toString().trim();
                String comfirmation = edtRegisterComfirmation.getText().toString().trim();

                if(TextUtils.isEmpty(email) || TextUtils.isEmpty(username) || TextUtils.isEmpty(password) || TextUtils.isEmpty(comfirmation))
                {
                    Toast.makeText(RegisterActivity.this, "Please Complete the Register Infomation!", Toast.LENGTH_LONG).show();
                }
                else
                {
                    if(password.equalsIgnoreCase(comfirmation))
                    {
                        UserDBHandler userDBHandler = new UserDBHandler(RegisterActivity.this);
                        userDBHandler.insertUserDetails(username,email,password);
                        Toast.makeText(RegisterActivity.this, "Apply Success!", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                        startActivity(intent);
                    }
                    else
                    {
                        Toast.makeText(RegisterActivity.this, "Please Enter the Same Password!", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
}

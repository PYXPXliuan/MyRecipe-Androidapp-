package com.example.myrecipesample;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashMap;

public class NoteDBHandler extends SQLiteOpenHelper {

    private static final int DB_VERSION = 1;
    private static final String DB_NAME = "notesdb";
    private static final String TABLE_Recipe = "notedetails";
    private static final String KEY_RNID = "recipeid";
    private static final String KEY_RNNAME = "recipename";
    private static final String KEY_USERID = "uid";
    private static final String KEY_KW1 = "keyword1";
    private static final String KEY_KW2 = "keyword2";
    private static final String KEY_KW3 = "keyword3";
    private static final String KEY_INGDTS = "ingredients";
    private static final String KEY_STEP1 = "step1";
    private static final String KEY_STEP2 = "step2";
    private static final String KEY_STEP3 = "step3";
    private static final String KEY_STEP4 = "step4";

    public ArrayList<HashMap<String, String>> recipeList = new ArrayList<>();
    public ArrayList<HashMap<String, String>> resultList = new ArrayList<>();

    public NoteDBHandler(@Nullable Context context)
    {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase rndb) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_Recipe
                + "(" + KEY_RNID + " INTEGER PRIMARY KEY AUTOINCREMENT," + KEY_RNNAME + " TEXT," + KEY_USERID + " TEXT,"
                + KEY_KW1 + " TEXT," + KEY_KW2 + " TEXT," + KEY_KW3 + " TEXT," + KEY_INGDTS + " TEXT,"
                + KEY_STEP1 + " TEXT," + KEY_STEP2 + " TEXT," + KEY_STEP3 + " TEXT," + KEY_STEP4 + " TEXT"
                + ")";

        rndb.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase rndb, int i, int i1) {
        rndb.execSQL("DROP TABLE IF EXISTS " + TABLE_Recipe);
        onCreate(rndb);
    }

    //Create

    public void insertNoteDetails(String recipename, String userid, String keyword1, String keyword2, String keyword3,
                                  String ingredients, String step1, String step2, String step3, String step4)
    {
        SQLiteDatabase rndb = this.getWritableDatabase();

        ContentValues cValues = new ContentValues();
        cValues.put(KEY_RNNAME, recipename);
        cValues.put(KEY_USERID, userid);
        cValues.put(KEY_KW1, keyword1);
        cValues.put(KEY_KW2, keyword2);
        cValues.put(KEY_KW3, keyword3);
        cValues.put(KEY_INGDTS, ingredients);
        cValues.put(KEY_STEP1, step1);
        cValues.put(KEY_STEP2, step2);
        cValues.put(KEY_STEP3, step3);
        cValues.put(KEY_STEP4, step4);

        long newRoid = rndb.insert(TABLE_Recipe, null, cValues);
        rndb.close();
    }

    //getList

    public ArrayList<HashMap<String, String>> getRecipe(String userid) {

        SQLiteDatabase rndb = this.getWritableDatabase();

        String query = "SELECT recipeid, recipename, uid, keyword1, keyword2, keyword3, ingredients, step1, step2, step3, step4 FROM " + TABLE_Recipe + " WHERE uid=?";

        Cursor cursor = rndb.rawQuery(query, new String[]{String.valueOf(userid)});

        while (cursor.moveToNext()) {

            HashMap<String, String> recipe = new HashMap<>();
            recipe.put("recipeid", cursor.getString(cursor.getColumnIndex(KEY_RNID)));
            recipe.put("recipename", cursor.getString(cursor.getColumnIndex(KEY_RNNAME)));
            recipe.put("userid", cursor.getString(cursor.getColumnIndex(KEY_USERID)));
            recipe.put("keyword1", cursor.getString(cursor.getColumnIndex(KEY_KW1)));
            recipe.put("keyword2", cursor.getString(cursor.getColumnIndex(KEY_KW2)));
            recipe.put("keyword3", cursor.getString(cursor.getColumnIndex(KEY_KW3)));
            recipe.put("ingredients", cursor.getString(cursor.getColumnIndex(KEY_INGDTS)));
            recipe.put("step1", cursor.getString(cursor.getColumnIndex(KEY_STEP1)));
            recipe.put("step2", cursor.getString(cursor.getColumnIndex(KEY_STEP2)));
            recipe.put("step3", cursor.getString(cursor.getColumnIndex(KEY_STEP3)));
            recipe.put("step4", cursor.getString(cursor.getColumnIndex(KEY_STEP4)));

            recipeList.add(recipe);
        }
        rndb.close();
        return recipeList;
    }

    //delete

    public void DeleteNote(String recipeID)
    {
        SQLiteDatabase rndb = this.getWritableDatabase();
        rndb.delete(TABLE_Recipe, KEY_RNID + " = ? ", new String[]{String.valueOf(recipeID)});
        rndb.close();
    }

    //Update

    public int UpdateRecipeDetails(String recipename, String keyword1, String keyword2, String keyword3,
                                   String ingredients, String step1, String step2, String step3, String step4,
                                   String recipeID)
    {
        SQLiteDatabase rndb = this.getWritableDatabase();

        ContentValues cValues = new ContentValues();
        cValues.put(KEY_RNNAME, recipename);
        cValues.put(KEY_KW1, keyword1);
        cValues.put(KEY_KW2, keyword2);
        cValues.put(KEY_KW3, keyword3);
        cValues.put(KEY_INGDTS, ingredients);
        cValues.put(KEY_STEP1, step1);
        cValues.put(KEY_STEP2, step2);
        cValues.put(KEY_STEP3, step3);
        cValues.put(KEY_STEP4, step4);

        int count = rndb.update(TABLE_Recipe, cValues,KEY_RNID + " = ? ", new String[]{String.valueOf(recipeID)});

        return count;
    }

    //read

    public HashMap<String, String> ricipedetail(String recipeid) {

        SQLiteDatabase rndb = this.getWritableDatabase();

        String query = "SELECT recipeid, recipename, uid, " +
                "keyword1, keyword2, keyword3, ingredients, " +
                "step1, step2, step3, step4 FROM " + TABLE_Recipe + " WHERE recipeid =?";

        Cursor cursor = rndb.rawQuery(query, new String[]{String.valueOf(recipeid)});
        HashMap<String, String> recipe = new HashMap<String, String>();

        while(cursor.moveToNext())
        {
            recipe.put("recipeid", cursor.getString(cursor.getColumnIndex(KEY_RNID)));
            recipe.put("recipename", cursor.getString(cursor.getColumnIndex(KEY_RNNAME)));
            recipe.put("userid", cursor.getString(cursor.getColumnIndex(KEY_USERID)));
            recipe.put("keyword1", cursor.getString(cursor.getColumnIndex(KEY_KW1)));
            recipe.put("keyword2", cursor.getString(cursor.getColumnIndex(KEY_KW2)));
            recipe.put("keyword3", cursor.getString(cursor.getColumnIndex(KEY_KW3)));
            recipe.put("ingredients", cursor.getString(cursor.getColumnIndex(KEY_INGDTS)));
            recipe.put("step1", cursor.getString(cursor.getColumnIndex(KEY_STEP1)));
            recipe.put("step2", cursor.getString(cursor.getColumnIndex(KEY_STEP2)));
            recipe.put("step3", cursor.getString(cursor.getColumnIndex(KEY_STEP3)));
            recipe.put("step4", cursor.getString(cursor.getColumnIndex(KEY_STEP4)));
        }

        rndb.close();
        return recipe;
    }

    //get Search result

    public ArrayList<HashMap<String, String>> getResultRecipe(String userid, String keyword) {

        SQLiteDatabase rndb = this.getWritableDatabase();

        String query = "SELECT recipeid, recipename, uid, keyword1, keyword2, keyword3, ingredients, step1, step2, step3, step4 FROM " + TABLE_Recipe
                + " WHERE (recipename=? OR keyword1=? OR keyword2=? OR keyword3=?) AND uid=?";

        Cursor cursor = rndb.rawQuery(query, new String[]{String.valueOf(keyword), String.valueOf(keyword),String.valueOf(keyword), String.valueOf(keyword), String.valueOf(userid)});

        while (cursor.moveToNext()) {

            HashMap<String, String> recipe = new HashMap<>();
            recipe.put("recipeid", cursor.getString(cursor.getColumnIndex(KEY_RNID)));
            recipe.put("recipename", cursor.getString(cursor.getColumnIndex(KEY_RNNAME)));
            recipe.put("userid", cursor.getString(cursor.getColumnIndex(KEY_USERID)));
            recipe.put("keyword1", cursor.getString(cursor.getColumnIndex(KEY_KW1)));
            recipe.put("keyword2", cursor.getString(cursor.getColumnIndex(KEY_KW2)));
            recipe.put("keyword3", cursor.getString(cursor.getColumnIndex(KEY_KW3)));
            recipe.put("ingredients", cursor.getString(cursor.getColumnIndex(KEY_INGDTS)));
            recipe.put("step1", cursor.getString(cursor.getColumnIndex(KEY_STEP1)));
            recipe.put("step2", cursor.getString(cursor.getColumnIndex(KEY_STEP2)));
            recipe.put("step3", cursor.getString(cursor.getColumnIndex(KEY_STEP3)));
            recipe.put("step4", cursor.getString(cursor.getColumnIndex(KEY_STEP4)));

            resultList.add(recipe);
        }
        rndb.close();
        return resultList;
    }

    //check exist
    public boolean CheckUser(String recipeid, String recipename)
    {
        SQLiteDatabase rndb = this.getWritableDatabase();

        String checkinfo = "SELECT * FROM " + TABLE_Recipe + " WHERE recipeid=? AND recipename=?";

        Cursor cursor = rndb.rawQuery(checkinfo, new String[]{String.valueOf(recipeid), String.valueOf(recipename)});

        if(cursor.getCount() > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

}

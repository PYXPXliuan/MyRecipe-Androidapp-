package com.example.myrecipesample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

public class AddNoteActivity extends AppCompatActivity {

    private EditText edtName;
    private EditText edtKw1;
    private EditText edtKw2;
    private EditText edtKw3;
    private EditText edtIngredients;
    private EditText edtStep1;
    private EditText edtStep2;
    private EditText edtStep3;
    private EditText edtStep4;


    private Button btnSave;
    private Button btnBack;

    Intent getPassdata;
    String userid = null;
    String recipeid = null;
    String activity = null;

    HashMap<String, String> recipeDetail = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        getPassdata = getIntent();

        getAddView();

        getpassInfo();

        getRecipeDetail();

        setRecipeDetail();

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //String userid = edtKw1.getText().toString();
                //int recipeid = edtKw1.getText().toString();

                String recipename = edtName.getText().toString();
                String keyword1 = edtKw1.getText().toString();
                String keyword2 = edtKw2.getText().toString();
                String keyword3 = edtKw3.getText().toString();
                String ingredients = edtIngredients.getText().toString();
                String step1 = edtStep1.getText().toString();
                String step2 = edtStep2.getText().toString();
                String step3 = edtStep3.getText().toString();
                String step4 = edtStep4.getText().toString();

                if(activity.equalsIgnoreCase("view"))
                {
                    NoteDBHandler notedbHandler = new NoteDBHandler(AddNoteActivity.this);
                    notedbHandler.UpdateRecipeDetails(recipename, keyword1, keyword2, keyword3,
                            ingredients, step1, step2, step3, step4, recipeid);

                    Intent intent = new Intent(AddNoteActivity.this, ViewNoteActivity.class);
                    intent.putExtra("recipeid", (String) recipeid);
                    //pass ativity
                    intent.putExtra("activity", (String) "add");

                    startActivity(intent);
                }
                else if(activity.equalsIgnoreCase("main"))
                {
                    NoteDBHandler notedbHandler = new NoteDBHandler(AddNoteActivity.this);
                    notedbHandler.insertNoteDetails(recipename, userid, keyword1, keyword2, keyword3,
                            ingredients, step1, step2, step3, step4);

                    Intent intent = new Intent(AddNoteActivity.this, MainActivity.class);
                    //pass ativity
                    intent.putExtra("activity", (String) "add");
                    intent.putExtra("userid", (String) userid);

                    startActivity(intent);
                }


            }
        });;

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(AddNoteActivity.this, MainActivity.class);
                //pass ativity
                intent.putExtra("activity", (String) "add");
                intent.putExtra("userid", (String) userid);

                startActivity(intent);
            }
        });

    }

    private void getAddView()
    {
        edtName = (EditText)findViewById(R.id.edtName);
        edtKw1 = (EditText)findViewById(R.id.edtKeyWord1);
        edtKw2 = (EditText)findViewById(R.id.edtKeyWord2);
        edtKw3 = (EditText)findViewById(R.id.edtKeyWord3);
        edtIngredients = (EditText)findViewById(R.id.edtIngredients);
        edtStep1 = (EditText)findViewById(R.id.edtStep1);
        edtStep2 = (EditText)findViewById(R.id.edtStep2);
        edtStep3 = (EditText)findViewById(R.id.edtStep3);
        edtStep4 = (EditText)findViewById(R.id.edtStep4);

        btnSave = (Button) findViewById(R.id.btnSave);
        btnBack = (Button) findViewById(R.id.btnBack);
    }

    private void getpassInfo()
    {
        activity = getPassdata.getStringExtra("activity");

        try
        {
            activity = getPassdata.getStringExtra("activity");

            if(activity.equalsIgnoreCase("view"))
            {
                recipeid = getPassdata.getStringExtra("recipeid");

                btnBack.setVisibility(View.GONE);

                if(recipeid == null)
                {
                    Toast.makeText(AddNoteActivity.this, "Error happen 0", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(AddNoteActivity.this, MainActivity.class);
                    //pass ativity
                    intent.putExtra("activity", (String) "add");
                    startActivity(intent);
                }
            }
            else if(activity.equalsIgnoreCase("main"))
            {
                userid = getPassdata.getStringExtra("userid");

                if(userid == null)
                {
                    Toast.makeText(AddNoteActivity.this, "Error happen 1", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(AddNoteActivity.this, MainActivity.class);
                    //pass ativity
                    intent.putExtra("activity", (String) "add");
                    startActivity(intent);
                }
            }
            else if(activity == null)
            {
                Toast.makeText(AddNoteActivity.this, "Error happen 2", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(AddNoteActivity.this, MainActivity.class);
                //pass ativity
                intent.putExtra("activity", (String) "add");
                startActivity(intent);
            }
        }
        catch (Exception e)
        {
            Toast.makeText(AddNoteActivity.this, "Error happen 3", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(AddNoteActivity.this, MainActivity.class);
            //pass ativity
            intent.putExtra("activity", (String) "add");
            startActivity(intent);
        }
    }

    private  void getRecipeDetail()
    {
        NoteDBHandler noteDBHandler = new NoteDBHandler(AddNoteActivity.this);
        recipeDetail = noteDBHandler.ricipedetail(recipeid);
    }

    private void setRecipeDetail()
    {
        edtName.setText(recipeDetail.get("recipename"));
        edtKw1.setText(recipeDetail.get("keyword1"));
        edtKw2.setText(recipeDetail.get("keyword2"));
        edtKw3.setText(recipeDetail.get("keyword3"));
        edtIngredients.setText(recipeDetail.get("ingredients"));
        edtStep1.setText(recipeDetail.get("step1"));
        edtStep2.setText(recipeDetail.get("step2"));
        edtStep3.setText(recipeDetail.get("step3"));
        edtStep4.setText(recipeDetail.get("step4"));
        recipeid = recipeDetail.get("recipeid");
    }
}

package com.example.myrecipesample;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class UserDBHandler extends SQLiteOpenHelper {

    private static final int DB_VERSION = 1;
    private static final String DB_NAME = "usersdb";
    private static final String TABLE_USERS = "userdetails";
    private static final String KEY_UID = "userid";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_USERPW = "password";


    public UserDBHandler(@Nullable Context context)
    {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase udb) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_USERS
                + "(" + KEY_UID + " INTEGER PRIMARY KEY AUTOINCREMENT," + KEY_USERNAME + " TEXT," + KEY_EMAIL + " TEXT," + KEY_USERPW + " TEXT" + ")";

        udb.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase udb, int i, int i1) {
        udb.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(udb);
    }

    public void insertUserDetails(String username, String email, String password)
    {
        SQLiteDatabase udb = this.getWritableDatabase();

        ContentValues cValues = new ContentValues();
        cValues.put(KEY_USERNAME, username);
        cValues.put(KEY_EMAIL, email);
        cValues.put(KEY_USERPW, password);

        long newRoid = udb.insert(TABLE_USERS, null, cValues);
        udb.close();
    }

    public String[] logincheck(String email, String ActualPassword)
    {
        SQLiteDatabase udb = this.getWritableDatabase();

        String[] columns = {"userid", "username", "email"};
        String selection = "email=? AND password=?";

        Cursor cursor = (Cursor) udb.query(TABLE_USERS, columns, selection, new String[]{String.valueOf(email),String.valueOf(ActualPassword)},null,null,null,null);


        if(cursor.getCount() > 0)
        {
            String[] userinfo = new String[3];

           while(cursor.moveToNext())
           {
               userinfo[0] = cursor.getString(cursor.getColumnIndex(KEY_UID));
               userinfo[1] = cursor.getString(cursor.getColumnIndex(KEY_USERNAME));
               userinfo[2] = cursor.getString(cursor.getColumnIndex(KEY_EMAIL));
           }
            return userinfo;
        }
        else
        {
            return null;
        }
    }
}

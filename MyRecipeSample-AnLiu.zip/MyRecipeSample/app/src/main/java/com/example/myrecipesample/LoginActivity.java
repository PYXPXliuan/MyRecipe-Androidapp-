package com.example.myrecipesample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private EditText edtEmail;
    private EditText edtPassword;
    private Button btnLogin;
    private TextView txtApply;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edtEmail = (EditText)findViewById(R.id.edtEmail);
        edtPassword = (EditText)findViewById(R.id.edtPassword);
        btnLogin = (Button)findViewById(R.id.btnLogin);
        txtApply = (TextView)findViewById(R.id.txtApply);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //get user input
                String Email = edtEmail.getText().toString();
                String Password = edtPassword.getText().toString();
                //check the existence of user
                UserDBHandler userDBHandler = new UserDBHandler(LoginActivity.this);
                String[] userinfo = userDBHandler.logincheck(Email,Password);

                if(userinfo != null)
                {
                    Toast.makeText(LoginActivity.this, "Login Succeed!", Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);

                    //pass ativity
                    intent.putExtra("activity", (String) "login");
                    //pass user info
                    intent.putExtra("userid",userinfo[0]);
                    intent.putExtra("username",userinfo[1]);

                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(LoginActivity.this, "Your Email or Password is incorrect! Please Enter again! ", Toast.LENGTH_LONG).show();
                    edtEmail.setText("");
                    edtPassword.setText("");
                }
            }
        });

        txtApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}

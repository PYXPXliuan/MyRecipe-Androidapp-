package com.example.myrecipesample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private ListView ReciptListView;
    private TextView txtUsername;
    private FloatingActionButton flbtnAddNote;
    private FloatingActionButton flbtnSignOut;
    private SearchView schSearch;

    //get user info
    Intent getUserinfo;
    private String activity = null;
    private String userid = null;
    private String username = null;

    //get recipelist
    private ArrayList<HashMap<String, String>> recipeList = new ArrayList<HashMap<String, String>>();

    //get recipeid
    public String recipeid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getUserinfo = getIntent();

        setView();

        getUserinfoAndRecipelist();

        displayList();


        flbtnAddNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddNoteActivity.class);

                //pass user info
                intent.putExtra("userid",userid);
                //pass ativity
                intent.putExtra("activity", (String) "main");

                startActivity(intent);
            }
        });

        flbtnSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        schSearch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            //click to search
            @Override
            public boolean onQueryTextSubmit(String newText) {
                if(newText != "")
                {
                    displayResultList(newText);
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Please Enter Keyword for Search!", Toast.LENGTH_LONG).show();
                    displayList();
                }
                return false;
            }

            //tpye to search
            @Override
            public boolean onQueryTextChange(String newText) {

                displayResultList(newText);
                return false;
            }
        });

        schSearch.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                displayList();
                return false;
            }
        });

        ReciptListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                recipeid = recipeList.get(i).get("recipeid").toString();

                Intent intent = new Intent(MainActivity.this, ViewNoteActivity.class);

                intent.putExtra("recipeid", (String) recipeid);
                //pass ativity
                intent.putExtra("activity", (String) "main");

                startActivity(intent);
            }
        });
    }

    private void getUserinfoAndRecipelist()
    {
        try
        {
            //get user info
            activity = getUserinfo.getStringExtra("activity");
            if(activity == null)
            {
                Toast.makeText(MainActivity.this, "Error happen, you cannot use app now!", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
            else if(activity.equalsIgnoreCase("login")||activity.equalsIgnoreCase("add")||activity.equalsIgnoreCase("view"))
            {
                //get recipelist
                userid = getUserinfo.getStringExtra("userid");
                username = getUserinfo.getStringExtra("username");
                if(userid == null)
                {
                    Toast.makeText(MainActivity.this, "Error happen 1", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    startActivity(intent);
                }
                else
                {
                    txtUsername.setText(username);
                    NoteDBHandler rndb = new NoteDBHandler(this);
                    recipeList = rndb.getRecipe(userid);
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Toast.makeText(MainActivity.this, "Error happen 2", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
        }
    }

    private void setView()
    {
        schSearch = (SearchView) findViewById(R.id.schSearch);

        txtUsername = (TextView) findViewById(R.id.txtUsername);

        ReciptListView = (ListView)findViewById(R.id.listRecipe);

        flbtnAddNote = (FloatingActionButton)findViewById(R.id.flbtnAddNote);
        flbtnSignOut = (FloatingActionButton)findViewById(R.id.flbtnSignOut);
    }

    private void displayList()
    {
        NoteDBHandler rndb = new NoteDBHandler(this);
        recipeList = new ArrayList<HashMap<String, String>>();
        recipeList = rndb.getRecipe(userid);
        ListAdapter adapter = new SimpleAdapter(MainActivity.this,
                recipeList, R.layout.list_row,
                new String[]{"userid", "recipename", "keyword1", "keyword2", "keyword3"},
                new int[]{R.id.txtIdList,R.id.txtRcipeNameList,R.id.txtKeyword1List,R.id.txtKeyword2List,R.id.txtKeyword3List});
        ReciptListView.setAdapter(adapter);
    }

    private void displayResultList(String Keyword)
    {
        NoteDBHandler rndb = new NoteDBHandler(this);
        recipeList = new ArrayList<HashMap<String, String>>();
        recipeList = rndb.getResultRecipe(userid,Keyword);
        ListAdapter adapter = new SimpleAdapter(MainActivity.this,
                recipeList, R.layout.list_row,
                new String[]{"userid", "recipename", "keyword1", "keyword2", "keyword3"},
                new int[]{R.id.txtIdList,R.id.txtRcipeNameList,R.id.txtKeyword1List,R.id.txtKeyword2List,R.id.txtKeyword3List});
        ReciptListView.setAdapter(adapter);
    }
}
